#include "Enemy.h"
#include "Player.h"
#include "functions.h"
#include <cstdlib>
#include <cmath>
#include <string>
#include <iostream>
using std::cout, std::cin, std::string, std::endl;

Enemy::Enemy() {
	name = "nullEnemy";
	hp = 1;
	maxHp= 1;
	minDamage = 1;
	maxDamage = 1;
	critChance = 0;
	armor = 0;
	money = 1;
}
Enemy::Enemy(string name, float maxHp, int minDamage, int maxDamage, short critChance, short armor, int money, int xpReward)
	: name(name), hp(maxHp),maxHp(maxHp), minDamage(minDamage),maxDamage(maxDamage),critChance(critChance),armor(armor),money(money), xpReward(xpReward) 
{}

std::pair<int, int> Enemy::CalculateDamage() const{
	int baseDamage = getRandomNumber(minDamage, maxDamage);
	bool getCrit = getRandomNumber(1,100) < critChance;
	//cout << "Random Damage got: " << damage<<"\n";
	int finalDamage = getCrit ? round((float)baseDamage * 1.5) : baseDamage; // damage after crit + 50% 
	//cout << "Damage after critChance: " << damage<<"\n";
	return { finalDamage, baseDamage };
}
void Enemy::Attack(class Player& target) {
	if (hp > 0) {
	std::cout << "\n-------------------------------------------";
	auto damageData = CalculateDamage();
	int afterCritDamage = damageData.first;
	int baseDamage = damageData.second;
	bool isCrit = afterCritDamage > baseDamage; // if final damage > base damage => its a crit
	int finalDamage = target.TakeDamage(afterCritDamage);
	int blockedDamage = afterCritDamage - finalDamage;
	std::cout << "\n[COMBAT, ENEMY's TURN] Enemy " << name << " attacks Player " << target.getName()<< "\n";

	std::cout << "--> Base damage: " << baseDamage << "\n";
	if (isCrit) cout << "[CRITICAL DAMAGE]\n--> Damage after crit: " << afterCritDamage << "\n";
	if (blockedDamage > 0) {
		std::cout << "--> " << target.getName() << "'s armor (" << target.getArmor()<< " class) blocked " << blockedDamage << " damage.\n";
	}
	std::cout << "--> Result: Dealt " << finalDamage << " damage leaving player with " << target.getHp()<< " HP.";
	std::cout << "\n-------------------------------------------\n\n";
	}
}
int Enemy::TakeDamage(int damage) {
	damage = armor <= 4 ? damage - damage *(armorClassFormula(armor)): damage - damage * 4.0 / 5.0; // Damage reduces if there's armor. Can't be armor class greater than 4 tho
	//cout << "Damage after armor: " << damage << "\n"; 
	hp -= damage < hp ? damage : hp; // if dmg is greater than hp then u cry man
	return damage;
}

bool Enemy::isAlive() const{
	return hp > 0;
}
std::string Enemy::getName()const { return name; }
float Enemy::getHp()const { return hp; }
float Enemy::getMaxHp()const { return maxHp; }
int Enemy::getMinDamage()const { return minDamage; }
int Enemy::getMaxDamage()const { return maxDamage; }
short Enemy::getCritChance()const { return critChance; }
short Enemy::getArmor()const { return armor; }
int Enemy::getMoney()const { return money; }
int Enemy::getXpReward()const {
	return xpReward;}