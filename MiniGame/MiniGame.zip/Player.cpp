#include "Player.h"
#include "Weapon.h"
#include "Enemy.h"
#include "functions.h"
#include <cmath>
#include <cstdlib>
#include <string>
#include <iostream>

using std::cout, std::cin, std::string, std::endl;

Player::Player(int level, int money, Weapon* currentWeapon, short armor)
	:level(level),money(money),maxHp(getMaxHpFormula()), hp(getMaxHpFormula()), currentWeapon(currentWeapon), armor(armor)
{
	
}
std::pair<int, int> Player::CalculateDamage()const{
	int minDamage = getMinDamage();
	int maxDamage = getMaxDamage();
	bool getCrit= getRandomNumber(1,100) < getCritChance();
	int baseDamage = getRandomNumber(minDamage, maxDamage);
	//cout << "Random Damage got: " << damage<<"\n";
	int finalDamage= getCrit? round((float)baseDamage* 1.5) : baseDamage; // damage after crit + 50% 
	//cout << "Damage after critChance: " << damage<<"\n";
	return { finalDamage,baseDamage};
}
void Player::Attack(Enemy& target) {
	if (hp > 0) {

	std::cout << "\n-------------------------------------------";
	auto damageData = CalculateDamage();
	int afterCritDamage = damageData.first;
	int baseDamage = damageData.second;
	bool isCrit = afterCritDamage > baseDamage; // if final damage > base damage => its a crit
	int finalDamage = target.TakeDamage(afterCritDamage);
	int blockedDamage = afterCritDamage - finalDamage;
	std::cout << "\n[COMBAT, PLAYER'S TURN] Player " << name << " attacks " << target.getName()<< "\n";
	
	std::cout << "--> Base damage: " << baseDamage << "\n";
	if (isCrit) cout << "[CRITICAL DAMAGE]\n--> Damage after crit: "<<afterCritDamage<<"\n";
	if (blockedDamage > 0) {
		std::cout << "--> " << target.getName() << "'s armor (" << target.getArmor()<< " class) blocked " << blockedDamage << " damage.\n";
	}
	std::cout << "--> Result: Dealt " << finalDamage << " damage leaving enemy with " << target.getHp()<< " HP.";
	std::cout << "\n-------------------------------------------\n\n";
	}
}
int Player::TakeDamage(int damage) {
	damage = armor <= 4 ? damage - damage * (armorClassFormula(armor)) : damage - damage * 4.0 / 5.0; // Damage reduces if there's armor. Can't be armor class greater than 4 tho
	//cout << "Damage after armor: " << damage << "\n"; 
	hp -= damage<hp?damage:hp; // if dmg is greater than hp then u cry man
	return damage;
}
bool Player::isAlive()const { // Checking if Player's alive
	return hp > 0;
}
void Player::AddXp(int amount) { // Adding XP to a player, if levels up then reduces xp required for lvl in case they have xp for leveling up to few more levels
	
	playerXp += amount;
	while (playerXp >= xpToNextLvl) {
		std::cout << "\n-------------------------------------------";
		level++;
		std::cout << "\n[LEVEL] you leveled up to " << level << " level\n";
		playerXp -= xpToNextLvl;
		xpToNextLvl =getLevelXpFormula();
		maxHp = getMaxHpFormula();
		hp = hp + 10 > maxHp ? maxHp : hp+10;
		cout << "HP: " << hp;
		cout << "\nMax HP: " << maxHp;
		cout << "\nCurrent XP: " << playerXp;
		cout << "\nXP to next " << level + 1 << " level: " << xpToNextLvl;
		std::cout << "\n-------------------------------------------\n";
	}
}
void Player::HealPlayer() {
	const float HEAL_PRICE_PERHP = (static_cast<float>(level) * HEAL_COST_PER_LVL + BASE_HEAL_COST);
	int totalCost = round(HEAL_PRICE_PERHP * (maxHp - hp));
	char choice; // for checkin Y and N
	int numChoice; // for choosing hp
	bool leaving = false;
	std::cout << "\n-------------------------------------------\n";
	std::cout << "[HEALING MENU]\n";
	std::cout << "\nYour balance is " << money << "$\n";
	std::cout << "Your HP is " << hp << "\n";
	if (hp == maxHp) {
		std::cout << "You already have max HP of " << maxHp << "\n";
	}
	while (!leaving && hp != maxHp) { // repeating ts till user leaves menu
		if (money >= totalCost) {
			std::cout << "\nAre you sure you want to spend " << HEAL_PRICE_PERHP << "$ per hp to heal yourself to your max HP of " << maxHp << "\n";
			std::cout << "Healing to " << maxHp << " will cost you " << totalCost << "$\n";
			std::cout << "Type 'Y' if you agree, Type 'N' if you do not or want to heal to a specific number of HP\n";
			std::cin >> choice;

			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

			switch (toupper(choice)) {
			case 'Y':
				choice = ' ';
				money -= totalCost;
				hp = maxHp;
				std::cout << "You're successfully healed! Your HP now is " << hp << "!\n";
				leaving = true;
				break;

			case 'N':
				choice = ' ';
				std::cout << "Type '-1' if you want to leave this menu, Type a number " << hp + 1 << '-' << maxHp << " to choose HP to heal you for.\n";
				std::cin >> numChoice;

				std::cin.clear();
				std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
				if (numChoice == -1) leaving = true;
				else if ((numChoice > hp && numChoice <= maxHp)) { // checking if input number is available number to heal
					std::cout << "Healing to " << numChoice << " HP will cost you " << HEAL_PRICE_PERHP * (numChoice - hp) << "$" <<
						"\nType 'Y' if you agree to heal, type 'N' to leave this menu\n";
					std::cin >> choice;
					std::cin.clear();
					std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
					if (toupper(choice) == 'Y') {
						money -= HEAL_PRICE_PERHP * (numChoice - hp);
						std::cout << "You have successfully healed to " << numChoice << " HP! And spent " << HEAL_PRICE_PERHP * (numChoice - hp) << "$\n";
						hp = numChoice;
						leaving = true;
					}
					else {
						leaving = true;
					}
				}
				else {
					std::cout << "Error! Try again!\n";
				}
				break;
			default:
				std::cout << "Error! Try again!\n";
				break;
			}
		}
		else
		{
			if (money >= HEAL_PRICE_PERHP) {
				std::cout << "\nYou have not enough money to heal you to " << maxHp << " HP (that costs " << totalCost << "$)\n";
				std::cout << "Heal Price per 1 HP = " << HEAL_PRICE_PERHP << "\n";
				std::cout << "Type '-1' if you want to leave this menu, Type a number " << hp + 1 << '-' << (int)(hp + (money / HEAL_PRICE_PERHP)) << " to choose HP to heal you for.\n";
				std::cin >> numChoice;
				std::cin.clear();
				std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
				if (numChoice == -1) leaving = true;
				else if (numChoice > hp && numChoice <= (hp + (money / HEAL_PRICE_PERHP))) {
					std::cout << "Healing to " << numChoice << " HP will cost you " << HEAL_PRICE_PERHP * (numChoice - hp) << "$" <<
						"\nType 'Y' if you agree to heal, type 'N' to leave this menu\n";
					std::cin >> choice;
					std::cin.clear();
					std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
					if (toupper(choice) == 'Y') {
						money -= HEAL_PRICE_PERHP * (numChoice - hp);
						std::cout << "You have successfully healed to " << numChoice << " HP! And spent " << HEAL_PRICE_PERHP * (numChoice - hp) << "$\n";
						hp = numChoice;
						leaving = true;
					}
				}
				else {
					std::cout << "Error! Try again!\n";
				}
			}
			else {
				std::cout << "\nYou don't even have enough money to heal you for 1 HP lol (it's " << HEAL_PRICE_PERHP << "$ per 1 HP" << "\n";
				leaving = true;
			}
		}
	}
	std::cout << "-------------------------------------------\n";
}


std::vector<Weapon*>& Player::getInventory() {
	return inventory;
}
const std::vector<Weapon*>& Player::getInventory() const {
	return inventory;
}

int Player::getMinDamage()const {
	return currentWeapon->getMinDMG() + (level * 2);
}
int Player::getMaxDamage()const {
	return currentWeapon->getMaxDMG() + (level * 2);
}
int Player::getCritChance() const {
	return currentWeapon->getCritChance();
}
int Player::getArmorPrice(short armorClass) const{
	return armorClass * armorClass * 100;
}

void Player::addWeaponToInventory(Weapon* weapon) {
	inventory.push_back(weapon);
}
std::string Player::getName()const { return name; }
void Player::setName(string sName) { name = sName; }
float Player::getMaxHp()const { return maxHp; }
float Player::getHp()const { return hp; }
Weapon* Player::getCurrentWeapon()const { return currentWeapon; }
void Player::setCurrentWeapon(Weapon* weapon) {
	currentWeapon = weapon;
}
short Player::getArmor()const { return armor; }
void Player::setArmor(short num){ armor = num; }
int Player::getLevel()const { return level; }
int Player::getPlayerXp()const { return playerXp; }
int Player::getXpToNextLvl()const { return xpToNextLvl; }
int Player::getMoney()const { return money; }
void Player::addMoney(int num) { if (num > 0)money += num; }
void Player::spendMoney(int num) { if (num > 0) money -= num; }
int Player::getKills()const { return kills; }
void Player::addKills(int num){ kills+=num; }